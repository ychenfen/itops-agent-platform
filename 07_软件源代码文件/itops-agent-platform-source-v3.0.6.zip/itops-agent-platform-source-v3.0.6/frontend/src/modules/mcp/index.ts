export { mcpRoutes } from './routes';
